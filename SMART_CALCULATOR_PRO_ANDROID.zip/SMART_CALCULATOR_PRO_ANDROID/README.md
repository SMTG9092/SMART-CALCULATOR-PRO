# SMART CALCULATOR PRO — Android WebView project

This Android project packages the supplied `SMART CALCULATOR PRO.html` as a local WebView app.

## Build APK

1. Open this folder as a project in Android Studio (or push it to a GitHub repository).
2. Build with Gradle: `gradle assembleDebug`.
3. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Push the project to GitHub and run **Build SMART CALCULATOR PRO APK** from the Actions tab. Download the generated artifact.

## Network note

The supplied HTML loads Tailwind CSS, Font Awesome, Chart.js and Google Fonts from online CDNs. The app therefore needs an internet connection for those external assets to load. The calculator data/history itself uses browser local storage on the device.
